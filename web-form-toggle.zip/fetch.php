<?php
include 'connect.php';
$result = $conn->query("SELECT * FROM users");

echo "<table><tr><th>Name</th><th>Age</th><th>Status</th><th>Action</th></tr>";
while ($row = $result->fetch_assoc()) {
    $status = $row['status'] == 1 ? "Active" : "Inactive";
    echo "<tr>
        <td>{$row['name']}</td>
        <td>{$row['age']}</td>
        <td>{$status}</td>
        <td><button class='toggle-btn' onclick='toggleStatus({$row['id']})'>Toggle</button></td>
    </tr>";
}
echo "</table>";
?>