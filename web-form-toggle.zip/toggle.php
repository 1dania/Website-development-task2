<?php
include 'connect.php';
$id = $_GET['id'];
$result = $conn->query("SELECT status FROM users WHERE id=$id");
$row = $result->fetch_assoc();
$new_status = $row['status'] == 1 ? 0 : 1;
$conn->query("UPDATE users SET status=$new_status WHERE id=$id");
?>