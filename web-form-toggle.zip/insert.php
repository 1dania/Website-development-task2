<?php
include 'connect.php';
$name = $_POST['name'];
$age = $_POST['age'];
$conn->query("INSERT INTO users (name, age, status) VALUES ('$name', $age, 0)");
?>