document.getElementById("dataForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch("insert.php", {
        method: "POST",
        body: formData
    })
    .then(() => {
        this.reset();
        loadData();
    });
});

function loadData() {
    fetch("fetch.php")
        .then(res => res.text())
        .then(data => {
            document.getElementById("recordsTable").innerHTML = data;
        });
}

function toggleStatus(id) {
    fetch("toggle.php?id=" + id)
        .then(() => loadData());
}

window.onload = loadData;